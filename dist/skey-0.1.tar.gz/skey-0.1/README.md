SKey Python package published on PyPI.

## Installation

```bash
pip install skey
